
main()
{
        syscall(0,"tstpr1 is working!\r\n");
        while(1);
}

